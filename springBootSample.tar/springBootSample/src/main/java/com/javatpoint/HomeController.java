package com.javatpoint;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController  
public class HomeController {  
    @RequestMapping("/hello")  
    public String hello(){  
        return"Hello spring boot here!";  
    } 
    
    @RequestMapping(value="/hello",method=RequestMethod.GET)  
    public String helloGET(){  
        return"Hello spring boot from GET!";  
    } 
    
    
    @RequestMapping(value="/hello",method=RequestMethod.POST)  
    public HttpServletResponse helloPOST(String data,HttpServletResponse res){  
    	res.setStatus(200);
    	try {
			res.getOutputStream().print("{\"message\":\"success\"}");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return res;
        		
    } 
    
}  
